Mug Cake Ingredients
You likely already have all the ingredients for this chocolate mug cake recipe on hand. Here’s what you’ll need: 

Flour: This easy chocolate mug cake recipe starts with all-purpose flour. 
Sugar: Sugar sweetens things up and balances the bitter cocoa powder. 
Cocoa powder: Two tablespoons of unsweetened cocoa powder ensures a rich chocolate cake. 
Baking soda: Baking soda acts as a leavening agent, which means it helps the mug cake rise. 
Salt: A pinch of salt enhances the overall flavor of the mug cake, but it won’t make it taste salty. 
Milk: Milk keeps the cake batter from drying out during the microwaving process. 
Oil: A neutral oil, such as canola oil, keeps the batter moist without adding flavor. 
Water: A tablespoon of water helps create the perfect texture. 
Vanilla: A dash of vanilla extract is the perfect finishing touch. 

Directions
Mix flour, sugar, cocoa powder, baking soda, and salt together in a large microwave-safe mug; stir in milk, canola oil, water, and vanilla extract.

Cook in the microwave until cake is done in the middle, about 1 minute 45 seconds.
